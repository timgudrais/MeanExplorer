$SeedProjectPath = "cd 'C:\Users\sun\Desktop\DevTest\MeanExplorer\seed-project\Node-Angular'"
$RunNodeBackEnd = "npm start"

Invoke-Expression $SeedProjectPath
Invoke-Expression $RunNodeBackEnd